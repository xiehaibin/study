//
//  main.m
//  Test
//
//  Created by 陈希 on 2017/11/2.
//  Copyright © 2017年 aone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
