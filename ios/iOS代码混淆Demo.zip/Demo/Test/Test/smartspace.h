//
//  smartspace.h
//  smartspace
//
//  Created by 陈希 on 2017/11/1.
//  Copyright © 2017年 aone. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface smartspace : NSObject

+ (void)startWorking;

@end
