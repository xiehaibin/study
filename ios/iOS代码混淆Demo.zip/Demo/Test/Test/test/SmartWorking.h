
#import <Foundation/Foundation.h>

@interface SmartWorking : NSObject

+ (instancetype)shareInstance;

- (void)workingWithIdentifyID:(NSString *)identifyID;

@end
