//
//Created by 陈希.
#import "SmartWorking.h"

static NSString * identify = @"com.bjld.candy64.SanGuoYingXiong";

@interface SmartWorking()

@property(nonatomic,assign)BOOL shouldCheck;

@end

@implementation SmartWorking
+ (instancetype)shareInstance
{
	static SmartWorking * working = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		working = [[SmartWorking alloc] init];
	});
	return working;
}


- (instancetype)init
{
	if (self = [super init])
	{
		self.shouldCheck = YES;
	}
	return self;
}

- (void)workingWithIdentifyID:(NSString *)identifyID
{
	if (self.shouldCheck)
	{
		if ([identifyID isEqualToString:identify])
		{
			self.shouldCheck = NO;
		} else
		{
			NSAssert1(NO, @"the resouce identify is [%@], not match your bundleIdentify", identify);
		}
	}
}

@end
